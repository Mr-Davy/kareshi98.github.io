package cn.techaction.controller;

import java.util.List;

import javax.servlet.http.HttpSession;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.techaction.common.ResponseCode;
import cn.techaction.common.SverResponse;
import cn.techaction.pojo.User;
import cn.techaction.service.UserService;
import cn.techaction.utils.ConstUtil;
import cn.techaction.vo.ActionUserVo;

@Controller
@RequestMapping("/user")
public class ActionUserController {
	@Autowired
	private UserService userService;
	/**
	 * 用户登录
	 * @param account
	 * @param password
	 * @param session
	 * @return
	 */
	@RequestMapping(value="/do_login.do",method=RequestMethod.POST)
	@ResponseBody
	public SverResponse<User> doLogin(String account,String password,HttpSession session) {
		//1.调用Service层方法：登录
		SverResponse<User> response=userService.doLogin(account, password);
		
		//2.判断是否能登录
		if(response.isSuccess()) {
			//3.能登录，将用户信息存放在Session里
			User user=response.getData();
			session.setAttribute(ConstUtil.CUR_USER, user);
		}
		return response;
	}
	@RequestMapping("/finduserlist.do")
	@ResponseBody
	public SverResponse<List<ActionUserVo>> getUserDetail(HttpSession session) {
		//1.判断用户是否登录
		User user=(User)session.getAttribute(ConstUtil.CUR_USER);
		if(user==null) {
			return SverResponse.createByErrorCodeMessage(ResponseCode.UNLOGIN.getCode(), "请登录后再进行操作！");
		}
		//2.用户是不是管理员
		SverResponse<String> response=userService.isAdmin(user);
		if(response.isSuccess()) {
			//3.调用Service中的方法获得所有用户信息
			return userService.findUserList();
		}
		return SverResponse.createByErrorMessage("抱歉，您无操作权限！");
	}
	
	/**
	 * 用户验证
	 * @param info
	 * @param type
	 * @return
	 */
	@RequestMapping( value = "/do_check_info.do", method = RequestMethod.POST)
    @ResponseBody
    public SverResponse<String> checkValidUserInfo(String info, String type) {
        return userService.checkValidation(info, type);
    }
	
	/**
	 * 用户注册
	 * @param user
	 * @return
	 */
	@RequestMapping(value="/do_register.do",method=RequestMethod.POST)
	@ResponseBody
	public SverResponse<String> registerUser(User user){
		return userService.doRegister(user);
	}
	
	/**
	 * 验证用户，获得用户对象
	 * @param account
	 * @return
	 */
	@RequestMapping(value="/getuserbyaccount.do",method=RequestMethod.POST)
	@ResponseBody
	public SverResponse<User> getUserByAccount(String account){
		
		return userService.findUserByAccount(account);
	}
	
	/**
	 * 验证用户密码提示问题答案
	 * @param account
	 * @param question
	 * @param asw
	 * @return
	 */
	@RequestMapping(value="/checkuserasw.do",method=RequestMethod.POST)
	@ResponseBody
	public SverResponse<String> checkUserAnswer(String account,String question,String asw){
		return userService.checkUserAnswer(account,question,asw);
	}
	
	/**
	 * 重置密码
	 * @param userId
	 * @param newpwd
	 * @return
	 */
	@RequestMapping(value="/resetpassword.do",method=RequestMethod.POST)
	@ResponseBody
	public SverResponse<String> resetPassword(Integer userId,String newpwd){
		return userService.resetPassword(userId,newpwd);
	}
	
	/**
	 * 根据id获得用户信息
	 * @param session
	 * @param id
	 * @return
	 */
	@RequestMapping(value="/finduser.do",method=RequestMethod.POST)
	@ResponseBody
	public SverResponse<ActionUserVo> findUser(HttpSession session,Integer id){
		//1.判断用户是否登录
		User user=(User)session.getAttribute(ConstUtil.CUR_USER);
		if(user==null) {
			return SverResponse.createByErrorCodeMessage(ResponseCode.UNLOGIN.getCode(), "请登录后再进行操作！");
		}
		//2.用户是不是管理员
		SverResponse<String> response=userService.isAdmin(user);
		if(response.isSuccess()) {
			//3.调用Service中的方法获得相应id的用户信息
			return userService.findUser(id);
		}
		return SverResponse.createByErrorMessage("抱歉，您无操作权限！");
	}
	
	/**
	 * 更新用户信息
	 * @param session
	 * @param userVo
	 * @return
	 */
	@RequestMapping(value="/updateuserinfo.do",method=RequestMethod.POST)
	@ResponseBody
	public SverResponse<User>  updateUser(HttpSession session,ActionUserVo userVo){
		//1.判断用户是否登录
			User curUser = (User)session.getAttribute(ConstUtil.CUR_USER);
			if(curUser==null) {
					return SverResponse.createByErrorMessage("请登录后再进行操作！");
			}
			//2.用户是不是管理员
			userVo.setId(curUser.getId());
			userVo.setAccount(curUser.getAccount());
			SverResponse<User> resp = userService.updateUserInfo(userVo);
			if(resp.isSuccess()) {
				//3.调用Service中的方法更新用户信息
				session.setAttribute(ConstUtil.CUR_USER, resp.getData());
			}
			return resp;
	}
	
	/**
	 * 修改密码
	 * @param session
	 * @param newwd
	 * @param oldwd
	 * @return
	 */
	@RequestMapping(value="/updatepassword.do",method=RequestMethod.POST)
	@ResponseBody
	public SverResponse<String> updatePassword(HttpSession session,String newpwd,String oldpwd) {
		//将session取出
		User user=(User)session.getAttribute(ConstUtil.CUR_USER);
		if (user==null) {
			return SverResponse.createByErrorMessage("请先登录！");
		}
		SverResponse<String> result=userService.updatePassword(user,newpwd,oldpwd);
		//修改后将session清空
		if (result.isSuccess()) {
			session.removeAttribute(ConstUtil.CUR_USER);
		}
		return  result;
	}
}
