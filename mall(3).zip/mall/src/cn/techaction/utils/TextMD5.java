package cn.techaction.utils;

public class TextMD5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String psw="1234";
		String md5pwd=MD5Util.MD5Encode(psw, "utf-8", false);
		System.out.println(md5pwd);
	}

}
