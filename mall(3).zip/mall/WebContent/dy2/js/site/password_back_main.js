require.config({
	 paths: {
			 "jquery": "/mall/dy2/js/jquery-1.6.2.min",
			 },

 });

require(['jquery','common','password_back'],function (jquery,common, password_back){
	
});